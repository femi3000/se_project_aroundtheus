# Project 3: Around The U.S.

### Overview

- Intro
- Figma
- Images

**Intro**

This project is made so all the elements are displayed correctly on popular screen sizes. We recommend investing more time in completing this project, since it's more difficult than previous ones.

**Figma**

- [Link to the project on Figma](https://www.figma.com/file/ii4xxsJ0ghevUOcssTlHZv/Sprint-3%3A-Around-the-US?node-id=0%3A1)

**Images**

The way you'll do this at work is by exporting images directly from Figma — we recommend doing that to practice more. Don't forget to optimize them [here](https://tinypng.com/), so your project loads faster.

**Video Link**

Good luck and have fun!

1. Project Name
   1a. Around the US - Sprint 3

2. The sprint shows the flexibility of using grids and flexboxes to maintain the format of the site

3. For this sprint i utilized flexboxes and grid layouts to maintain a friction free diplay grid to showcase a series of images and text associated with those images.

4. I will wait until all of my edits are complete before creating a video
